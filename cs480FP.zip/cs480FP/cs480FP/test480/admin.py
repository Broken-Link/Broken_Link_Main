from django.contrib import admin

# Register your models here.
from .models import Tag, Recipe
admin.site.register(Tag)
#admin.site.register(Recipe)


@admin.register(Recipe) 
class RecipeAdmin(admin.ModelAdmin):
    list_display = ('title', 'ingredients', 'instructions', 'display_tag')
