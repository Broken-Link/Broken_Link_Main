from django.urls import path
from django.views.generic import TemplateView
from django.conf.urls import url
from django.urls import include
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('database/', views.database, name = 'database'),
    path('results/', views.results, name='results'),
    path('accountPage/', views.accountPage, name ='accountPage'),
    path('indexAP', views.indexAP, name = 'indexAP'),
    path('apResults/', views.apResults, name='apResults'),
    path('apFeed/', views.apFeed, name='apFeed'),
    path('login/', views.index, name='index'),
    url(r'^$', views.index, name='index')
#url(r'^$', views.profile,name='profile'),

    ]
