from django.contrib import admin

# Register your models here.
from .models import Recipe, Ingredients

@admin.register(Recipe) 
class RecipeAdmin(admin.ModelAdmin):
    list_display = ('name', 'steps')


@admin.register(Ingredients) 
class IngredientAdmin(admin.ModelAdmin):
    list_display = ('name', 'recipe', 'measurement', 'unit')
