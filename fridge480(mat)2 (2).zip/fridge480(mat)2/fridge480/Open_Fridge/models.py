# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class OfficialAccount(models.Model):
    username = models.CharField(db_column='Username', primary_key=True, max_length=30)  # Field name made lowercase.
    email_address = models.CharField(db_column='Email Address', max_length=45)  # Field name made lowercase. Field renamed to remove unsuitable characters.
    password = models.CharField(db_column='Password', max_length=40)  # Field name made lowercase.
    created_recipes = models.CharField(db_column='Created Recipes', max_length=500, blank=True, null=True)  # Field name made lowercase. Field renamed to remove unsuitable characters.
    posts = models.CharField(db_column='Posts', max_length=500, blank=True, null=True)  # Field name made lowercase.
    friends = models.CharField(db_column='Friends', max_length=500, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = 'default'
        db_table = 'Official Account'
        unique_together = (('username', 'password', 'email_address'),)


class OfficialAccountHasRecipe(models.Model):
    official_account_username = models.ForeignKey(OfficialAccount, models.DO_NOTHING, related_name = 'account_account_has_set', db_column='Official Account_Username')  # Field name made lowercase. Field renamed to remove unsuitable characters.
    official_account_password = models.ForeignKey(OfficialAccount, models.DO_NOTHING, related_name = 'account_password_has_set', db_column='Official Account_Password')  # Field name made lowercase. Field renamed to remove unsuitable characters.
    official_account_email_address = models.ForeignKey(OfficialAccount, models.DO_NOTHING, related_name = 'account_email_has_set', db_column='Official Account_Email Address')  # Field name made lowercase. Field renamed to remove unsuitable characters.
    recipe_tags = models.CharField(db_column='Recipe_Tags', max_length=250)  # Field name made lowercase.
    recipe_title = models.CharField(db_column='Recipe_Title', max_length=45)  # Field name made lowercase.

    class Meta:
        managed = 'default'
        db_table = 'Official Account_has_Recipe'
        unique_together = (('official_account_username', 'official_account_password', 'official_account_email_address', 'recipe_tags', 'recipe_title'),)


class Recipe(models.Model):
    steps = models.TextField(db_column='Steps')  # Field name made lowercase.
    tags = models.CharField(db_column='Tags', primary_key=True, max_length=250)  # Field name made lowercase.
    ratings = models.CharField(db_column='Ratings', max_length=45, blank=True, null=True)  # Field name made lowercase.
    ingredients = models.TextField(db_column='Ingredients')  # Field name made lowercase.
    comments = models.TextField(db_column='Comments', blank=True, null=True)  # Field name made lowercase.
    title = models.CharField(db_column='Title', max_length=45)  # Field name made lowercase.

    class Meta:
        managed = 'default'
        db_table = 'Recipe'
        unique_together = (('tags', 'title'),)

