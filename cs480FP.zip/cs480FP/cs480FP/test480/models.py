from django.db import models

# Create your models here.
    
class Tag(models.Model):
    """
    Model representing a ingredients.
    """
    name = models.CharField(max_length=200, help_text="Enter a tag")
    
    def __str__(self):
        """
        String for representing the Model object (in Admin site etc.)
        """
        return self.name
       
    
class Recipe(models.Model):
    """
    Model representing a recipe.
    """
    title = models.CharField(max_length=200, help_text="Enter the name of the recipe")
    ingredients = models.TextField(default= " ", help_text="Enter all the ingredients for this recipe")
    instructions = models.TextField(help_text="Enter the recipe's instructions")
    tags = models.ManyToManyField(Tag, help_text="Select a tag for this reciper")
    
    def display_tag(self):
        """
        Creates a string for the Tag. This is required to display tag in Admin.
        """
        return ', '.join([ tags.name for tags in self.tags.all() ])
        display_genre.short_description = 'Tags'
    
    
    def get_absolute_url(self):
        """
        Returns the url to access a particular book instance.
        """
        return reverse('book-detail', args=[str(self.id)])

    def __str__(self):
        """
        String for representing the Model object.
        """
        return self.title
    


