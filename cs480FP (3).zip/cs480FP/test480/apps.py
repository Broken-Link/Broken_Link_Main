from django.apps import AppConfig


class Test480Config(AppConfig):
    name = 'test480'
