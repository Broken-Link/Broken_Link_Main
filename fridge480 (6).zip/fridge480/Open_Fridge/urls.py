from django.urls import path
from django.views.generic import TemplateView
from django.conf.urls import url
from . import views
from . import forms


urlpatterns = [
    path('', views.index, name='index'),
    path('database/', views.database, name = 'database'),
    path('results/', views.results, name='results'),
    path('accountPage/', views.accountPage, name ='accountPage'),
    path('indexAP', views.indexAP, name = 'indexAP'),
    path('apResults/', views.apResults, name='apResults'),
    path('apFeed/', views.apFeed, name='apFeed'),
    path('myRecipes/', views.myRecipes, name='myRecipes'),
    path('login/', views.index, name='index'),
    url(r'^$', views.index, name='index'),
    path('register_page/', views.register_page, name = 'register_page'),
    path('addRecipe/', views.addRecipe, name = 'addRecipe'),
    ]
