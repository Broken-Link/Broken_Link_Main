from django.shortcuts import get_object_or_404, render
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse

# Create your views here.
from .models import Recipe
def index(request):
    """
    View function for home page of site.
    """
    # Generate counts of some of the main objects
    list_recipes = Recipe.objects.all()
    num_recipes=Recipe.objects.all().count()
    
    # Render the HTML template index.html with the data in the context variable
    return render(
        request,
        'index.html',
        context={'list_recipes' : list_recipes, 'num_recipes' : num_recipes},
    )

def database(request) :
    """
    View function for database of site.
    """
    # Generate counts of some of the main objectss
    list_recipes = Recipe.objects.all()
    num_recipes = Recipe.objects.all().count()
    
    # Render the HTML template index.html with the data in the context variable
    return render(
        request,
        'database.html',
        context={'list_recipes' : list_recipes, 'num_recipes' : num_recipes},
    )

def results(request):

    key = request.GET.get('q')
    list_recipes = Recipe.objects.all().filter(title__icontains = key)
    print(key)
    print(list_recipes)
    if len(list_recipes) > 0:
        q = request.GET['q']
        list_recipes = Recipe.objects.filter(title__icontains= q)
        return render(request, 'results.html', context ={'list_recipes' : list_recipes, 'searched' : q},)
    else:
        error = "Couldn't find a recipe with that title"
        return render(request, 'index.html', context={ 'error' : error},)
    

def accountPage(request):
    return render(request, 'accountPage.html', context ={},)

def indexAP(request):
    """
    View function for AP home page of site.
    """

    return render(
        request,
        'indexAP.html',
        context={},
    )

def apResults(request):

    key = request.GET.get('q')
    list_recipes = Recipe.objects.all().filter(title__icontains = key)
    print(key)
    print(list_recipes)
    if len(list_recipes) > 0:
        q = request.GET['q']
        list_recipes = Recipe.objects.filter(title__icontains= q)
        return render(request, 'apResults.html', context ={'list_recipes' : list_recipes, 'searched' : q},)
    else:
        error = "Couldn't find a recipe with that title"
        return render(request, 'indexAP.html', context={ 'error' : error},)
    
def apFeed(request):
    return render(
        request,
        'temp.html',
        context={},
    )

def login_view(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password='password')
    if user is not None:
        login(request, user)
        return redirect('accountPage')
    else:
        error = "Invalid Login Credentials!"
        return render(request, '')
