from django.urls import path
from django.views.generic import TemplateView
from django.conf.urls import url
from django.urls import include
from . import views
from . import forms


urlpatterns = [
  path('index/', Open_Fridge.views.index, name='index'),
  path('database/', Open_Fridge.views.database, name = 'database'),
  path('results/', Open_Fridge.views.results, name='results'),
  path('accountPage/', Open_Fridge.views.accountPage, name ='accountPage'),
  path('apResults/', Open_Fridge.views.apResults, name='apResults'),
  path('apFeed/', Open_Fridge.views.apFeed, name='apFeed'),
  path('login/', Open_Fridge.views.indexAP, name='login_view'),
  path('register_page/', Open_Fridge.views.register_page, name = 'register_page'),
]
