from django.shortcuts import get_object_or_404, render
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.template import RequestContext
from django.forms.formsets import formset_factory, BaseFormSet
from .forms import RegistrationForms, IngredientForms, BaseIngredientFormSet, RecipeForm
from django.contrib.auth.models import User

# Create your views here.
from .models import Recipe, Ingredients

def index(request):
    """
    View function for home page of site.
    """
    # Generate counts of some of the main objects
    list_recipes = Recipe.objects.all()
    num_recipes= Recipe.objects.all().count()
    
    # Render the HTML template index.html with the data in the context variable
    return render(
        request,
        'index.html',
        context={'list_recipes' : list_recipes, 'num_recipes' : num_recipes},
    )

def database(request) :
    """
    View function for database of site.
    """
    # Generate counts of some of the main objectss
    list_recipes = Recipe.objects.all()
    num_recipes = Recipe.objects.all().count()
    
    # Render the HTML template index.html with the data in the context variable
    return render(
        request,
        'database.html',
        context={'list_recipes' : list_recipes, 'num_recipes' : num_recipes},
    )

def results(request):

    if request.GET.get('q'):
        option = 'title'
        key = request.GET.get('q')
        list_recipes = Recipe.objects.all().filter(name__icontains = key)
        print(key)
        print(list_recipes)
        if len(list_recipes) > 0:
            q = request.GET['q']
            list_recipes = Recipe.objects.filter(name__icontains= q)
            return render(request, 'results.html', context ={'list_recipes' : list_recipes, 'searched' : q, 'option' : option},)
        else:
            error = "Couldn't find a recipe with that title"
            return render(request, 'index.html', context={ 'error' : error},)
    else:
        option = 'ingredient'
        include = request.GET.get('include')
        exclude = request.GET.get('exclude')
        list_recipes = Ingredients.objects.all().filter(name__icontains = exclude)
        for j in include:
            list_recipes = Ingredients.objects.filter(name__icontains = j)
            
        for i in list_recipes:
            list_recipes = list_recipes.exclude(name_icontains = i)
        print(include)
        print(exclude)
        print(list_recipes)
        return render(request, 'results.html', context = {'option': option, 'list_recipes' : list_recipes},)
        
#def ingredientResults(request):
    
 #   include = request.GET.get('include')
  #  exclude = request.GET.get('exclude')
   # print(include)
    #print(exclude)
    #return render(request, 'results.html', context = {},)
   # if len(list_recipes) > 0:
       # q = request.GET['q']
       # list_recipes = Recipe.objects.filter(name__icontains= q)
        #return render(request, 'results.html', context ={'list_recipes' : list_recipes, 'searched' : q},)
 #   else:
  #      error = "Couldn't find a recipe with those requirements"
   #     return render(request, 'index.html', context={ 'error' : error},)

def accountPage(request):
    return render(request, 'accountPage.html', context ={},)

def indexAP(request):
    """
    View function for AP home page of site.
    """

    return render(
        request,
        'indexAP.html',
        context={},
    )

def apResults(request):

    key = request.GET.get('q')
    list_recipes = Recipe.objects.all().filter(title__icontains = key)
    print(key)
    print(list_recipes)
    if len(list_recipes) > 0:
        q = request.GET['q']
        list_recipes = Recipe.objects.filter(title__icontains= q)
        return render(request, 'apResults.html', context ={'list_recipes' : list_recipes, 'searched' : q},)
    else:
        error = "Couldn't find a recipe with that title"
        return render(request, 'indexAP.html', context={ 'error' : error},)

def addRecipe(request):
    return render(
        request,
        'addRecipe.html',
        context={}
        )
    
def apFeed(request):
    return render(
        request,
        'temp.html',
        context={},
    )

def myRecipes(request):
    list_recipes = Recipe.objects.all()
    num_recipes=Recipe.objects.all().count()
    
    return render(
        request,
        'myRecipes.html',
        context={'list_recipes' : list_recipes, 'num_recipes' : num_recipes},
    )
        

def login(request):
    return render(
                request,
        'login.html',
        context={},
        )

def login_view(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password='password')
    if user is not None:
        login(request, user)
        return redirect('accountPage')
    else:
        error = "Invalid Login Credentials!"
        return render(request, '')

def register_page(request):
    if request.method == 'POST':
        form = RegistrationForms(request.POST)
        if form.is_valid():
            user = User.objects.create_user(username=form.cleaned_data['username'], password=form.cleaned_data['password1'], email=form.cleaned_data['email'])
        return HttpResponseRedirect('')
    form = RegistrationForms()
    #variables = RequestContext(request,{'form':form})
    return render(request,
                  'registration/register.html',
                   context={'form':form})

def recipe_register(request):
    IngredientFormSet = formset_factory(IngredientForms, formset=BaseIngredientFormSet)
    if request.method == "POST":
        recipe_form     = RecipeForm(request.POST)
        ingredient_formset = IngredientFormSet(request.POST)
        if recipe_form.is_valid() and ingredient_formset.is_valid():
            recipe = Recipe.objects.create(recipe_id = Recipe.objects.all().count() + 1, steps = form.cleaned_data['steps'], name = form.cleaned_data['name'], comments = "N/A")
            new_ingredients = []
            for ing_form in ingredient_formset:
                ing_form = Ingredients.objects.create(recipe_id = Recipe.objects.all().count(), ingredient = forms.cleaned_data['ingredient'], measurement = form.cleaned_data['measurement'], unit = form.cleaned_data['unit'], additionalinfo = form.cleaned_data['additionalinfo'])
        return HttpResponseRedirect('')
    recipe_form = RecipeForm()
    ingredient_formset = IngredientFormSet()
    context = {
       'ingredient_formset' : ingredient_formset,
       'recipe_form' : recipe_form,
    }
    return render(request, 'recipe_register.html', context)
