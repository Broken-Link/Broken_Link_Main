from django.apps import AppConfig


class OpenFridgeConfig(AppConfig):
    name = 'Open_Fridge'
